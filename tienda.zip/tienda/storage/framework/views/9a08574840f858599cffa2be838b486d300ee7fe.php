

<?php $__env->startSection('titulo'); ?>
    <title>Pedidos</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
<div class="card-body text-center bg-light ">
	<div class="container-sm bg-light">
        <h1>Pedidos</h1>
	</div>
    <div class="text-left">
       <?php if(!isset($datos)): ?>
            <h1>No tienes productos</h1>
        <?php endif; ?>
        <?php if(isset($datos) ): ?>
        <h3> <?php echo e(session('usuario')->nombre); ?> <?php echo e(session('usuario')->apellido_p); ?> <?php echo e(session('usuario')->apellido_m); ?> </h3>
        <h3>Tienes un total de pedidos:<?php echo e($total); ?></h3>
        <h3></h3>
       
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Id pedido</th>
                    <th>Total a pagar</th>
                    <th>Correo</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(session('usuario')->nombre); ?></td>
                        <td><?php echo e(session('usuario')->apellido_p); ?></td>
                        <td><?php echo e(session('usuario')->apellido_m); ?></td>
                        <td><?php echo e($c->id); ?></td>
                        <td><?php echo e($c->total); ?></td>
                        <td><?php echo e(session('usuario')->correo); ?></td>                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <canvas id="myChart" width="400" height="400"></canvas>
        </div> 
        <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tigre\Desktop\tienda\resources\views/pedidosUsuario.blade.php ENDPATH**/ ?>
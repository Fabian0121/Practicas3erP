

<?php $__env->startSection('titulo'); ?>
    <title>Inicio</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
<div class="card-body text-center bg-light ">
	<div class="container-sm bg-light">
        <h1>Productos</h1>
	</div>
    <div class="text-left">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Id: <?php echo e($loop->index + 1); ?></p>
            <p>Codigo de barras :<?php echo e($a->clave); ?></p>
            <p>Nombre :<?php echo e($a->nombre); ?></p>
            <p>Descripcion :<?php echo e($a->descripcion); ?></p>
            <p>Precio: <?php echo e($a->precio); ?></p>
            <p>Marca: <?php echo e($a->marca); ?></p>
            <br>
            <a href="<?php echo e(route('usuario.inicio.agregar',["id" => $a->id_producto])); ?>" class="btn btn-danger btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fas fa-trash-alt"></i>
                </span>
                <span class="text">Agregar a carrito</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tigre\Desktop\tienda\resources\views/inicio.blade.php ENDPATH**/ ?>
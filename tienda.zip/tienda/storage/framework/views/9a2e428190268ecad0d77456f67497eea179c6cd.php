

<?php $__env->startSection('titulo'); ?>
    <title>Inicio Admin</title>
    <link href="/css/app.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
<div class="card-body text-center bg-light ">
	<div class="container-sm bg-light">
        <h1>Productos</h1>
	</div>
    <div class="text-left">
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Id: <?php echo e($loop->index + 1); ?></p>
        <p>Codigo de barras :<?php echo e($a->clave); ?></p>
        <p>Nombre :<?php echo e($a->nombre); ?></p>
        <p>Descripcion :<?php echo e($a->descripcion); ?></p>
        <p>Precio: <?php echo e($a->precio); ?></p>
        <p>Marca: <?php echo e($a->marca); ?></p>
        <br>
        <label></label>
        <a href="<?php echo e(route('admin.editar',["id" => $a->id_producto])); ?>" class="btn btn-success btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-trash-alt"></i>
            </span>
            <span class="text">Editar</span>
        </a>
        <a href="<?php echo e(route('admin.eliminar',["id" => $a->id_producto])); ?>" class="btn btn-danger btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-trash-alt"></i>
            </span>
            <span class="text">Eliminar</span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div>
<a href="<?php echo e(route('admin.registrar')); ?>" class="btn-flotante">Nuevo Producto</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tigre\Desktop\tienda\resources\views/inicioAdmin.blade.php ENDPATH**/ ?>


<?php $__env->startSection('titulo'); ?>
    <title>Registrar Producto</title>
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
<div class="card-body text-center bg-light ">
    <div class="container-sm text-left ">
        <form class="login100-form validate-form" method="post" action="<?php echo e(route('admin.registrarForn')); ?>">
            <?php echo e(csrf_field()); ?>

                    <label class="login100-form-title">
                        <?php if(isset($estatus)): ?>
                                <?php if($estatus == "success"): ?>
                                    <label class="text-success"><?php echo e($mensaje); ?></label>
                                <?php elseif($estatus == "error"): ?>
                                    <label class="text-danger"><?php echo e($mensaje); ?></label>
                                <?php endif; ?>
                    	 <?php endif; ?>
                    </label>
            <h1>Registrar producto</h1>
            <p>Codigo de barras</p>
            <input type="text" name="codigo">
            <p>Nombre</p>
            <input type="text" name="nombre">
            <p>Descripcion</p>
            <input type="text" name="descripcion">
            <p>Precio</p>
            <input type="number" name="precio">
            <p>Marca</p>
            <input type="text" name="marca">
            <br><br><br>
            <label></label>
            <button class="btn btn-primary">
                Registrar
            </button>

        </form>
        <br><br><br>
        <a href="<?php echo e(route('admin.inicio')); ?>" class="btn btn-danger btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-trash-alt"></i>
            </span>
            <span class="text">Volver</span>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tigre\Desktop\tienda\resources\views/registroProducto.blade.php ENDPATH**/ ?>